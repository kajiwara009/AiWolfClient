package org.aiwolf.client.lib;

public class SentenceType {
	private UtteranceVerb uv;
	private int rate;

	public UtteranceVerb getUv() {
		return uv;
	}
	public void setUv(UtteranceVerb uv) {
		this.uv = uv;
	}
	public int getRate() {
		return rate;
	}
	public void setRate(int rate) {
		this.rate = rate;
	}



}
