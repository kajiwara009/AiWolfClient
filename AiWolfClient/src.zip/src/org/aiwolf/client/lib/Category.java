package org.aiwolf.client.lib;

public enum Category {
	COMINGOUT,
	ESTIMATE,
	RESULT,
	SKIP,
	OVER

}
