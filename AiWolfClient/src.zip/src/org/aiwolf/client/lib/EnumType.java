package org.aiwolf.client.lib;

public enum EnumType {
	ROLE,
	TEAM,
	SPECIES,
	GIFTED;
}
